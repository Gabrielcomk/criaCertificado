package com.example.demo;

import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.properties.TextAlignment;

public class CertificadoGenerator {

    public static void main(String[] args) throws Exception {

        String outputPath = "certificado.pdf";
        String backgroundPath = "C:\\Users\\Gabriel\\Documents\\demo\\background.png";

        // ✅ Fontes personalizadas
        PdfFont fontNome = PdfFontFactory.createFont("C:\\Users\\Gabriel\\Documents\\demo\\src\\main\\resources\\fonts\\GreatVibes-Regular.ttf", PdfFontFactory.EmbeddingStrategy.PREFER_EMBEDDED);
        PdfFont fontTexto = PdfFontFactory.createFont("C:\\Users\\Gabriel\\Documents\\demo\\src\\main\\resources\\fonts\\Montserrat-Black.ttf", PdfFontFactory.EmbeddingStrategy.PREFER_EMBEDDED);

        PdfWriter writer = new PdfWriter(outputPath);
        PdfDocument pdf = new PdfDocument(writer);

        Image bg = new Image(ImageDataFactory.create(backgroundPath));
        float imgWidth = bg.getImageWidth();
        float imgHeight = bg.getImageHeight();

        pdf.setDefaultPageSize(new PageSize(imgWidth, imgHeight));
        Document document = new Document(pdf);
        document.setMargins(0, 0, 0, 0);

        bg.setFixedPosition(0, 0);
        document.add(bg);

        // ✅ Dados variáveis
        String nomePessoa = "José Vitor";
        String data = "February 18, 2022";

        // ✅ Nome com fonte cursiva elegante
        document.add(new Paragraph(nomePessoa)
                .setFont(fontNome)
                .setFontSize(60)
                .setFontColor(ColorConstants.YELLOW)
                .setTextAlignment(TextAlignment.CENTER)
                .setFixedPosition(0, imgHeight - 390, imgWidth)
        );

        // ✅ Texto menor com fonte clean
        document.add(new Paragraph(data)
                .setFont(fontTexto)
                .setFontSize(18)
                .setFontColor(ColorConstants.WHITE)
                .setFixedPosition(150, imgHeight - 645, 300)
        );

        document.close();
        System.out.println("✅ Certificado com fonte personalizada gerado com sucesso!");
    }
}
