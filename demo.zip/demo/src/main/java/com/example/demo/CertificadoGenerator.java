package com.example.demo;

import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.properties.TextAlignment;

import java.io.InputStream;

public class CertificadoGenerator {

    public static void main(String[] args) throws Exception {

        String outputPath = "certificado.pdf";

        // Carrega recursos do classpath
        InputStream bgStream = CertificadoGenerator.class.getResourceAsStream("/background.png");
        InputStream fontNomeStream = CertificadoGenerator.class.getResourceAsStream("/fonts/GreatVibes-Regular.ttf");
        InputStream fontTextoStream = CertificadoGenerator.class.getResourceAsStream("/fonts/Montserrat-Black.ttf");

        if (bgStream == null || fontNomeStream == null || fontTextoStream == null) {
            throw new IllegalStateException("Erro: imagem ou fontes não encontradas em resources!");
        }

        PdfFont fontNome = PdfFontFactory.createFont(fontNomeStream.readAllBytes(), PdfFontFactory.EmbeddingStrategy.PREFER_EMBEDDED);
        PdfFont fontTexto = PdfFontFactory.createFont(fontTextoStream.readAllBytes(), PdfFontFactory.EmbeddingStrategy.PREFER_EMBEDDED);

        PdfWriter writer = new PdfWriter(outputPath);
        PdfDocument pdf = new PdfDocument(writer);

        // Cria imagem de fundo
        Image bg = new Image(ImageDataFactory.create(bgStream.readAllBytes()));
        float imgWidth = bg.getImageWidth();
        float imgHeight = bg.getImageHeight();

        pdf.setDefaultPageSize(new PageSize(imgWidth, imgHeight));
        Document document = new Document(pdf);
        document.setMargins(0, 0, 0, 0);

        bg.setFixedPosition(0, 0);
        document.add(bg);

        // Dados variáveis
        String nomePessoa = "José Vitor";
        String data = "February 18, 2022";

        document.add(new Paragraph(nomePessoa)
                .setFont(fontNome)
                .setFontSize(60)
                .setFontColor(ColorConstants.YELLOW)
                .setTextAlignment(TextAlignment.CENTER)
                .setFixedPosition(0, imgHeight - 390, imgWidth)
        );

        document.add(new Paragraph(data)
                .setFont(fontTexto)
                .setFontSize(18)
                .setFontColor(ColorConstants.WHITE)
                .setFixedPosition(150, imgHeight - 645, 300)
        );

        document.close();
        System.out.println("✅: " + outputPath);
    }
}
